﻿using System;

namespace Scripten_FinnPoels
{
    class Program
    {
        enum Weekdays { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday , Today};

        enum Direction { North, East, South, West, Stay };

        static void Main(string[] args)
        {

            #region DaysOfTheWeek
            Weekdays Today = Weekdays.Wednesday;

            switch (Today)
            {
                case Weekdays.Monday:
                    Console.WriteLine("Its monday today!");
                    break;
                case Weekdays.Tuesday:
                    Console.WriteLine("Its tuessday today!");
                    break;
                case Weekdays.Wednesday:
                    Console.WriteLine("Its wednesday today!");
                    break;
                case Weekdays.Thursday:
                    Console.WriteLine("Its thursday today!");
                    break;
                case Weekdays.Friday:
                    Console.WriteLine("Its friday today!");
                    break;
                case Weekdays.Saturday:
                    Console.WriteLine("Its saturday today!");
                    break;
                case Weekdays.Sunday:
                    Console.WriteLine("Its sunday today!");
                    break;
                case Weekdays.Today:
                    break;
                default:
                    break;
            }
            #endregion

            #region Directions

            string choice;
            Direction playerDirection;

            Console.WriteLine("Wich direction would you like to go? 1. (North), 2. (East), 3. (South), 4. (West)");
            choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    playerDirection = Direction.North;
                    break;
                case "2":
                    playerDirection = Direction.East;
                    break;
                case "3":
                    playerDirection = Direction.South;
                    break;
                case "4":
                    playerDirection = Direction.West;
                    break;
                default:
                    playerDirection = Direction.West;
                    break;
            }

            switch (playerDirection)
            {
                case Direction.North:
                    Console.WriteLine("You are walking to the north...");
                    break;
                case Direction.East:
                    Console.WriteLine("You are walking to the East...");
                    break;
                case Direction.South:
                    Console.WriteLine("You are walking to the South...");
                    break;
                case Direction.Stay:
                    Console.WriteLine("You stayed!");
                    break;
                default:
                    break;
            }


            #endregion

        }
    }
}