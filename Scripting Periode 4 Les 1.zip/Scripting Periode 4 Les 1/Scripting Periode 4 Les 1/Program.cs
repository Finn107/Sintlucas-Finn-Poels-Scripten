﻿using System;

namespace Scripting_Periode_4_Les_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 
             All types of operators
             +
            ++
            =
            ==
            -
            --
            >
            <
            =>
            =<
            &
            &&
             */


            // ASSIGNMENTS: LOGICAL OPERATORS

            #region AND operator
            // 01. Note down the symbol of the AND operator.
            // &&

            // 02. Explain what an AND operator is and what it does.
            // Compares values and then returns true if the two values are the same and if not it returns false.

            // 03. Finish the Truth table for the AND operator.
            //     A     | B     | C
            //     true  | true  | True
            //     true  | false | False
            //     false | true  | False
            //     false | false | False

            #endregion

            #region OR operator
            // 04. Note down the symbol of the OR operator.
            // ||
            // 05. Explain what an OR operator is and what it does.
            // It checks mulitiple values,if one of them is true it returns true, if not it returns false.

            // 06. Finish the Truth table for the OR operator.
            //     A     | B     | C
            //     true  | true  | True
            //     true  | false | True
            //     false | true  | True
            //     false | false | False

            #endregion

            #region NOT operator
            // 07. Note down the symbol of the NOT operator.
            // !
            // 08. Explain what an NOT operator is and what it does.
            // It inverts the value, so if something is false it returns true.

            #endregion

            #region Truth table coding
            // 09.
            // Write code that satisfies the following Truth tables
            // For the given values of A and B you need to write code that
            // calculates the correct value for C

            // You may write the code however you like.
            // Just IF statements might do the trick but... 
            // Try to use them in combination with logical operators and write clean readable code.

            //   a.  A     | B     | C
            //      -------|-------|------
            //       true  | true  | false
            //       true  | false | true
            //       false | true  | false
            //       false | false | true

            bool aA = false;
            bool aB = false;
            bool aC = aA && !aB;
            if (aA && aB)
            {
                aC = false;
            }
            Console.WriteLine("\n1:\n");
            Console.WriteLine(aC);

            //   b.  A     | B     | C
            //      -------|-------|------
            //       true  | true  | true
            //       true  | false | true
            //       false | true  | false
            //       false | false | true

            bool bA = true;
            bool bB = true;
            bool bC = bA && !bB;
            if (bA && bB)
            {
                bC = false;
            }
            Console.WriteLine("\n2:\n");
            Console.WriteLine(bC);

            //   c.  A     | B     | C
            //      -------|-------|------
            //       true  | true  | true
            //       true  | false | true
            //       false | true  | true
            //       false | false | true

            bool cA = true;
            bool cB = true;
            bool cC = cA && !cB;
            if (cA && cB)
            {
                cC = false;
            }
            Console.WriteLine("\n3:\n");
            Console.WriteLine(bC);

            #endregion

            Console.WriteLine();
            System.Threading.Thread.Sleep(3000);

            #region Weird car
            // 10.
            // A car has 3 booleans, 'hasFuel', 'hasElectricity' and 'canDrive'.
            Boolean hasFuel = true;
            Boolean hasElectricity = true;
            Boolean carDrive = true;
            string fuelSource;
            string fuelchoice2;
            string closegame;
            // the car can only drive when it has either fuel OR electricity.
            // It can not drive on both.
            // It is a weird car...
            // Write code which assigns the correct value to 'canDrive' depending on the available fuel.
            if (hasFuel == true || hasElectricity == true)
            {
                carDrive = true;
            }
            else
            {
                Console.WriteLine("You have no fuel or electricity... Find a gas station!");
            }
            if (carDrive == true)
            {
                Console.WriteLine("You can drive this car on both fuel sources, wich fuel source would you like to drive on? Fuel or Electricity?");
                fuelSource = Console.ReadLine();
                if (fuelSource == "Fuel")
                {
                    Console.WriteLine("You are driving on fuel now... if you want to drive on Electricity just type Electricity.");
                }
                if (fuelSource == "Electricity")
                {
                    Console.WriteLine("You are driving on Electricity now... if you want to drive on Fuel just type Fuel.");
                }
            }
                fuelchoice2 = Console.ReadLine();
                if (fuelchoice2 == "Electricity")
                {
                    Console.WriteLine("You are driving on Electricity now...");
                }
                fuelchoice2 = Console.ReadLine();
                if (fuelchoice2 == "Fuel")
                {
                    Console.WriteLine("You are driving on Fuel now...");
                }
            #endregion
        }
    }
}