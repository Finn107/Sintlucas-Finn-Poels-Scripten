﻿using System;

namespace DiceGame_Week3
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Concept
            Dobbelsteen spel maken
            Regels voorgelezen in console
            Dubbele dobbelsteen
            3 rondes, degene die het hoogste getal heeft (bij elkaar opgeteld) wint!
            Eind Concept */


            /* Regels 
            Max 4 spelers.
            2 Dobbelstenen waarvan elk 6 kanten heeft (1 t/m 6)
            3 rondes, degene die het hoogste getal heeft (bij elkaar opgeteld) wint!
            Eind Regels */


            /* Pseudocode
              
            ints...
            
            random rnt 

            Write Do you want to play? Type [y/n] to play or close the game. 
              als antwoord = y speel de game af
               anders als antwoord = n sluit het spel af.
                    anders Write [y/n] to play or close the game. 
            Write Regels
            Write You can play with 1-4 persons in 1 game. With how many are you?
            Als antwoord = 1 
            Okay, your going to be playing against a bot! Have fun!

            functie spel met bot
            {
            random numer kiezen...
            Write You rolled...
            Write The bot rolled...
            Wie heeft meer gerolled?
            Write ... Heeft deze ronde gewonnen!
            Speel score af
            Repeat t/m ronde 3
            Winnaar bekendmaken!
            Totale scores laten zien
            }

            functie spel met 2 spelers
            {
            random numer kiezen...
            Write Player 1 rolled...
            Write Player 2 rolled...
            Wie heeft meer gerolled?
            Write Player ... Heeft deze ronde gewonnen!
            Speel score af
            Repeat t/m ronde 3
            Winnaar bekendmaken!
            Totale scores laten zien
            }

            functie spel met 3 spelers
            {
            random numer kiezen...
            Write Player 1 rolled...
            Write Player 2 rolled...
            Write Player 3 rolled...
            Wie heeft meer gerolled?
            Write Player ... Heeft deze ronde gewonnen!
            Speel score af
            Repeat t/m ronde 3
            Winnaar bekendmaken!
            Totale scores laten zien
            }

            functie spel met 4 spelers
            {
            random numer kiezen...
            Write Player 1 rolled...
            Write Player 2 rolled...
            Write Player 3 rolled...
            Write Player 4 rolled...
            Wie heeft meer gerolled?
            Write Player ... Heeft deze ronde gewonnen!
            Speel score af
            Repeat t/m ronde 3
            Winnaar bekendmaken!
            Totale scores laten zien
            }

            ErrorMessage {
            Write 
            }

            Eind Pseudocode */


            /* Code */
            int botRandomNummer;
            int botRandomNummer2;
            int botPoints = 0;

            int player1RandomNummer;
            int player1RandomNummer2;
            int player1Points = 0;

            int player2RandomNummer;
            int player2RandomNummer2;
            int player2Points = 0;

            int player3randomNummer;
            int player3RandomNummer2;
            int player3Points = 0;

            int player4RandomNummer;
            int player4RandomNummer2;
            int player4Points = 0;

            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {

                Rules();

                Console.WriteLine("Do you want to play? Type [y/n] to play or close the game. ");
                if (Console.ReadLine() == "y")
                {
                    PlayGame();
                }
                else if (Console.ReadLine() == "n")
                {
                    
                }
                else
                {
                    ErrorMessage();
                }

                void PlayGame()
                {
                    

                }

                void ErrorMessage() {
                    Console.Clear();
                    Console.WriteLine("ERROR");
                }

                void Rules()
                {
                    Console.WriteLine("Rule 1: You can have between 1 and 4 players");
                    Console.WriteLine("Rule 2: Theres 2 dices wich each has 6 different sides (1 t / m 6)");
                    Console.WriteLine("Rule 3: 3 rounds, the one with the highest total number at the end wins!");
                }
            }

            /* Eind Code */
        }
    }
}