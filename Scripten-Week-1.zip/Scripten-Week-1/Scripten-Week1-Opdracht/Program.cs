﻿using System;
using System.Collections.Generic;

namespace Scripten_Week1_Opdracht
{
    class Program
    {
        static void Main(string[] args)
        {

            
            int[] authors = { 1, 2, 3, 4 };

            var numbers = new List<int>();

            var moreNumbers = new List<int>() { 1, 2, 3, 4 };

            #region AddItemToList

            var addItemToList = new List<int>() { 5, 6, 7, 8 };

            addItemToList.Add(9);
            addItemToList.Add(10);


            var addCollectionToList = new List<int>();
            Console.WriteLine(addCollectionToList.Count);

            int[] numbs = new int[] { 11, 12 };
            addCollectionToList.AddRange(numbs);
            Console.WriteLine(addCollectionToList.Count);

            #endregion

            #region CheckList

            var containsList = new List<string> { "aap", "ezel", "eend" };
            Console.WriteLine("Staat er ezel in de lijst? : " + containsList.Contains("ezel"));

            #endregion

            #region RemoveItemsFromList
            var removeItemFromList = new List<int>() { 1, 2 };

            removeItemFromList.Remove(3);
            removeItemFromList.RemoveAt(0);
            #endregion

            #region RemoveCollectionFromList

            var removeCollectionFromList = new List<int>() { 3, 5, 7, 3, 0, 2, 1 };

            removeCollectionFromList.RemoveRange(0, 2);

            #endregion

            #region EmptyList

            var emptyList = new List<string>() { "Banaan", "Appel", "Peer" };
            emptyList.Clear();
            Console.WriteLine(emptyList.Count);

            #endregion

            #region SortList

            var sortList = new List<int>() { 101, 20, 6, 46, 1, 3, 7 };
            sortList.Sort();
             
            sortList.Reverse();

            #endregion
        }
    }
}
