﻿using System;
using System.Collections.Generic;

namespace Week1._2_ListAndLoops
{
    class Program
    {
        static void Main(string[] args)
        {


            var Namelist = new List<string>() { "Banaan", "banaan", "Ezel", "ezel", "paard", "Paard", "appel","Appel", "Peer", "peer" };

            Console.WriteLine("Enter a name of your choice.");

            string choice = Console.ReadLine();

            Console.WriteLine("Lets check if the item exist in our list..." + Namelist.Contains(choice));

        }
    }
}