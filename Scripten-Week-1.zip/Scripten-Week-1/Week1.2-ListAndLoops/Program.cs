﻿using System;
using System.Collections.Generic;

namespace Week1._2_ListAndLoops
{
    class Program
    {
        static void Main(string[] args)
        {

            #region List with a loop

            var numberList = new List<int>() { 1, 2, 3, 4, 5 };

            #endregion

            #region 5xLoop
            for (int i = 0; i < 5; i++)
            {
                numberList.Add(i);
            }
            #endregion

            string[] themNames = new string[] {"Banaan", "Appel", "Ezel", "Jelle", "Bal" };
            var stringList = new List<string>();

            foreach (var name in themNames)
            {
                stringList.Add(name);
                Console.WriteLine(name);
                Console.WriteLine();
            }

            #region ForEachLoop

            var theThings = new List<string>() { "Peer", "Paard", "Tennisbal", "Doos" };

            foreach (var thing in theThings)
            {
                Console.WriteLine(thing);
            }

            #endregion

        }
    }
}
