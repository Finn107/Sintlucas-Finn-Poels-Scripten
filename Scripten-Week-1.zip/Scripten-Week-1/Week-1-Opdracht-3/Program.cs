﻿using System;
using System.Collections.Generic;

namespace Week_1_Opdracht_3
{
    class Program
    {
        static void Main(string[] args)
        {
            var addItemToList = new List<int>() { 5, 6, 7, 8 };

            Random rnd = new Random();
            int removernd = rnd.Next(0,3);

            addItemToList.RemoveAt(removernd);

            addItemToList.Sort();

            foreach (var item in addItemToList)
            {
                Console.WriteLine(item);
            }
        }
    }
}