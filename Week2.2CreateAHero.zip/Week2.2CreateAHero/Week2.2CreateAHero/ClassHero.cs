﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week1._2_Assignment
{
    class ClassHero
    {
        private string name;
        public string Name
        {
            get { return this.name; }
        }

        private int hp;
        public int Hp
        {
            get { return this.hp; }
        }

        private bool alive = true;
        public bool Alive
        {
            get { return this.alive; }
            set { this.alive = value; }
        }

        public ClassHero()
        {
            this.name = "Finn";
            this.hp = 50;
            this.alive = true;
        }
    }
}
