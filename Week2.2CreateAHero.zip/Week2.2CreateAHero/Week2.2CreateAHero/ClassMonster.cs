﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week2._2CreateAHero
{
    class ClassMonster
    {
        private string _type;
        int ChanceToFlee;


        public string Type
        {
            get { return this._type; }
            set { this._type = value; }
        }

        public ClassMonster()
        {
            this._type = "type";
        }

        public ClassMonster(string type)
        {
            this._type = type;
        }
    }
}
