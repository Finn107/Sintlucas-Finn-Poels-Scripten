﻿using System;

namespace Week2._2CreateAHero
{
    class Program
    {
        static void Main(string[] args)
        {

            string HeroName;

            #region Intro
            ClassMonster monster1 = new ClassMonster("Zombie");
            Console.WriteLine("A monster appears in front of you...");
            System.Threading.Thread.Sleep(1000);

            Console.WriteLine($"The type of the monster is... {monster1.Type}");
            System.Threading.Thread.Sleep(500);

            Console.WriteLine($"Good luck facing a {monster1.Type} monster...");
            System.Threading.Thread.Sleep(500);

            Console.WriteLine("What is your name?");
            HeroName = Console.ReadLine();
            #endregion

            #region Fight
            for (int i = 0; i < 5; i++)
            {
                AttackHero();
                System.Threading.Thread.Sleep(500);
                MonsterAttack();
                System.Threading.Thread.Sleep(500);
                Flee();
                System.Threading.Thread.Sleep(500);
            }
            #endregion

            /*
              The hero has the following attributes:
              *     - Hit points : when there are no hit points left the hero is incapacitated
              *     - Attack bonus 
              *  - The hero can do the following:
              *     - Attack : the hero does 1D12 damage + the attack bonus
              *     - Defend : when the hero defends it takes only half damage 

             */

            #region Properties
            void MonsterAttack()
            {
                int MonsterAttackDamage;
                int MonsterAttackDamage2;
                int MonsterAttackTotalDamage;

                Random random = new Random();
                MonsterAttackDamage = random.Next(1, 7);
                Random random2 = new Random();
                MonsterAttackDamage2 = random.Next(1, 7);

                MonsterAttackTotalDamage = MonsterAttackDamage + MonsterAttackDamage2;
                Console.WriteLine("The monster did " + MonsterAttackTotalDamage + " Damage!");

                bool HeroDefending = false;
                Random rand = new Random();

                if (rand.Next(1,3) != 1)
                {
                    HeroDefending = true;
                }
                System.Threading.Thread.Sleep(500);
                if (HeroDefending == true)
                {
                    Console.WriteLine("You have defended yourself!");
                    int monsterAttackTotalDamage = (MonsterAttackTotalDamage / 2);
                    Console.WriteLine("You still took " + monsterAttackTotalDamage + " damage!");
                }
                else
                {
                    Console.WriteLine("You have failed to defended yourself!");
                    Console.WriteLine("You took " + MonsterAttackTotalDamage + " damage!");
                }
            }

            void Flee()
            {
                bool FleeChance = false;
                Random rand = new Random();

                if (rand.Next(1, 15) != 1)
                {
                    FleeChance = true;
                    Console.Clear();
                }
                if(FleeChance == true)
                {
                    Console.WriteLine("The monster has ran away... The game will end...");
                    System.Threading.Thread.Sleep(10000);
                }
                else
                {

                }
            }

            void AttackHero()
            {
                int HeroAttackDamage;
                int CriticalChance;

                Random random = new Random();
                HeroAttackDamage = random.Next(1, 13);
                Random random2 = new Random();
                CriticalChance = random.Next(1, 3);

                bool CriticalHit = false;
                Random rand = new Random();

                if (rand.Next(1, 3) != 1)
                {
                    CriticalHit = true;
                }
                System.Threading.Thread.Sleep(500);
                if (CriticalHit == true)
                {
                    Console.WriteLine("You have critical hit the monster.");
                    int heroAttackDamage = (HeroAttackDamage * 2);
                    Console.WriteLine("You have hit your enemy for " + heroAttackDamage + " damage!");
                    int monsterhealth = 150;
                    monsterhealth = (monsterhealth - heroAttackDamage);
                    Console.WriteLine("Your enemy has " + monsterhealth + " health left...");
                }
                else
                {
                    int heroAttackDamage = (HeroAttackDamage * 1);
                    Console.WriteLine("You have hit your enemy for " + heroAttackDamage + " damage!");
                    int monsterhealth = 150;
                    monsterhealth = (monsterhealth - heroAttackDamage);
                    Console.WriteLine("Your enemy has " + monsterhealth + " health left...");
                }
            }
            #endregion
        }
    }
}
