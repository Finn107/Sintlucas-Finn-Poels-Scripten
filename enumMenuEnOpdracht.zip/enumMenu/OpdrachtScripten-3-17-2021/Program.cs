﻿using System;

namespace OpdrachtScripten_3_17_2021
{
    class Program
    {

        /* 
        Try to do the following using the example code 
        and information you find online.
        When you are get stuck don't stop but ask your classmate or teacher. 
        --------------------------------------

        Part 1: Directions...
        1. Create an enumerable type named 'Directions' containing all 4 directions north, south, east and west.
        Tip : Enums are defined before the Main method. 
        */
        enum Directions
        {
            North = 1,
            East = 2,
            South = 3,
            West = 4,
        }

        static void Main(string[] args)
        {

        /*  
        Part 2: 
        1. Declare a variable named 'playerDirection' of the enum 'Directions' type.
        */
            string playerDirection;
        /*
        2. Ask the user to input one of the available directions.
        */
            Console.WriteLine("Wich direction would you like to go? Your options are North, East, South and West.");
            playerDirection = Console.ReadLine();
            /*
            3. Use an if statment to check the input and display a different message for every possible option.
            */

            if (playerDirection == "North")
            {
                Console.WriteLine("Your walking to the North...");
            }
            if (playerDirection == "East")
            {
                Console.WriteLine("Your walking to the East...");
            }
            if (playerDirection == "South")
            {
                Console.WriteLine("Your walking to the South...");
            }
            if (playerDirection == "West")
            {
                Console.WriteLine("Your walking to the West...");
            }

            /*
            Part 3:
            1. Do the same as Part 2 but use the enum value instead of the name.
            2. If you're feeling adventurous you can try to use a foreach to create the menu from the enum 
            */

            string DirectionChosen;

            Console.WriteLine("Choose a direction, North, East, South or West.");

            DirectionChosen = Console.ReadLine();

            if (DirectionChosen == Directions.North.ToString())
            {
                Console.WriteLine("Your walking to the north...2");
            }
            else if (DirectionChosen == Directions.East.ToString())
            {
                Console.WriteLine("Your walking to the east...2");
            }
            else if (DirectionChosen == Directions.South.ToString())
            {
                Console.WriteLine("Your walking to the south...2");
            }
            else if (DirectionChosen == Directions.West.ToString())
            {
                Console.WriteLine("Your walking to the west...2");
            }
            /*
            --------------------------------------
            Save you work to OneDrive or, preferably, GitHub for Werkhouding points.
            Good luck!!!
            */
        }
    }
}
