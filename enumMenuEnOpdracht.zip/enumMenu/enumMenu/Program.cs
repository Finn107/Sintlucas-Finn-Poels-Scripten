﻿using System;
using System.Collections.Generic;

namespace enumMenu
{
    class Program
    {
        enum Menu
        {
            Quit,
            Rules = 5,
            Start,
        }

        static void Main(string[] args)
        {

            List<string> menu = new List<string> { "start", "rules", "quit" };

            Menu selectedMenu;
            selectedMenu = Menu.Start;
            Console.WriteLine(selectedMenu);


            selectedMenu = Menu.Rules;
            Console.WriteLine(selectedMenu);

            Menu disabledMenu;
            disabledMenu = Menu.Quit;

            Console.WriteLine(disabledMenu);


            int menuID = (int)Menu.Rules;
            Console.WriteLine("Menu ID for Rules is : " + menuID);

            int menuItem = (int)(Menu)2;
            Console.WriteLine("Name of menu value 2 : " + menuItem);


            foreach  (string mItem in Enum.GetNames(typeof(Menu)))
            {
                Console.WriteLine(mItem);
            }
        }
    }
}
